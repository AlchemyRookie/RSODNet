import torch
from ultralytics.nn.modules.conv import Conv, C2f_RepConv
from ultralytics.nn.modules.block import C2f
from ultralytics.nn.extra_modules.prune_module import *

# 没有购买yolov8项目需要注释以下
from ultralytics.nn.extra_modules.block import C2f_Faster, C2f_EMBC, C2f_DBB, C2f_Faster_EMA


def transfer_weights_c2f_v2_to_c2f(c2f_v2, c2f):
    c2f.cv2 = c2f_v2.cv2
    c2f.m = c2f_v2.m

    state_dict = c2f.state_dict()
    state_dict_v2 = c2f_v2.state_dict()

    # Transfer cv1 weights from C2f to cv0 and cv1 in C2f_v2
    old_weight = state_dict['cv1.conv.weight']
    new_cv1 = Conv(c1=state_dict_v2['cv0.conv.weight'].size()[1],
                   c2=(state_dict_v2['cv0.conv.weight'].size()[0] + state_dict_v2['cv1.conv.weight'].size()[0]),
                   k=c2f_v2.cv1.conv.kernel_size,
                   s=c2f_v2.cv1.conv.stride)
    c2f.cv1 = new_cv1
    c2f.c1, c2f.c2 = state_dict_v2['cv0.conv.weight'].size()[0], state_dict_v2['cv1.conv.weight'].size()[0]
    state_dict['cv1.conv.weight'] = torch.cat([state_dict_v2['cv0.conv.weight'], state_dict_v2['cv1.conv.weight']], dim=0)

    # Transfer cv1 batchnorm weights and buffers from C2f to cv0 and cv1 in C2f_v2
    for bn_key in ['weight', 'bias', 'running_mean', 'running_var']:
        state_dict[f'cv1.bn.{bn_key}'] = torch.cat([state_dict_v2[f'cv0.bn.{bn_key}'], state_dict_v2[f'cv1.bn.{bn_key}']], dim=0)

    # Transfer remaining weights and buffers
    for key in state_dict:
        if not key.startswith('cv1.'):
            state_dict[key] = state_dict_v2[key]

    # Transfer all non-method attributes
    for attr_name in dir(c2f_v2):
        attr_value = getattr(c2f_v2, attr_name)
        if not callable(attr_value) and '_' not in attr_name:
            setattr(c2f, attr_name, attr_value)

    c2f.load_state_dict(state_dict)

def replace_c2f_v2_with_c2f(module):
    for name, child_module in module.named_children():
        if isinstance(child_module, C2f_v2):
            # Replace C2f with C2f_v2 while preserving its parameters
            shortcut = infer_shortcut(child_module.m[0])
            c2f = C2f_infer(child_module.cv1.conv.in_channels, child_module.cv2.conv.out_channels,
                            n=len(child_module.m), shortcut=shortcut,
                            g=child_module.m[0].cv2.conv.groups,
                            e=child_module.c / child_module.cv2.conv.out_channels)
            transfer_weights_c2f_v2_to_c2f(child_module, c2f)
            setattr(module, name, c2f)
        else:
            replace_c2f_v2_with_c2f(child_module)
    
    # for name, child_module in module.named_children():    #弃用代码，不用管
    #     if isinstance(child_module, C2f_EMBC_v2):
    #         # Replace C2f with C2f_v2 while preserving its parameters
    #         shortcut = infer_shortcut(child_module.m[0])
    #         c2f = C2f_EMBC_infer(child_module.cv1.conv.in_channels, child_module.cv2.conv.out_channels,
    #                         n=len(child_module.m), shortcut=shortcut,
    #                         g=1,
    #                         e=child_module.c / child_module.cv2.conv.out_channels)
    #         transfer_weights_c2f_v2_to_c2f(child_module, c2f)
    #         setattr(module, name, c2f)
    #     elif isinstance(child_module, C2f_v2):
    #         # Replace C2f with C2f_v2 while preserving its parameters
    #         shortcut = infer_shortcut(child_module.m[0])
    #         c2f = C2f_infer(child_module.cv1.conv.in_channels, child_module.cv2.conv.out_channels,
    #                         n=len(child_module.m), shortcut=shortcut,
    #                         g=child_module.m[0].cv2.conv.groups,
    #                         e=child_module.c / child_module.cv2.conv.out_channels)
    #         transfer_weights_c2f_v2_to_c2f(child_module, c2f)
    #         setattr(module, name, c2f)
    #     else:
    #         replace_c2f_v2_with_c2f(child_module)

def infer_shortcut(bottleneck):
    try:
        c1 = bottleneck.cv1.conv.in_channels
        c2 = bottleneck.cv2.conv.out_channels
        return c1 == c2 and hasattr(bottleneck, 'add') and bottleneck.add
    except:
        return False

def transfer_weights_c2f_to_c2f_v2(c2f, c2f_v2):
    c2f_v2.cv2 = c2f.cv2    #C2f改进型中添加到层放在这里(如：c2f_v2.att = c2f.att)
    c2f_v2.m = c2f.m    #cv2和m转换后不变，所以写在这里

    state_dict = c2f.state_dict()
    state_dict_v2 = c2f_v2.state_dict()

    # Transfer cv1 weights from C2f to cv0 and cv1 in C2f_v2
    old_weight = state_dict['cv1.conv.weight']
    half_channels = old_weight.shape[0] // 2
    state_dict_v2['cv0.conv.weight'] = old_weight[:half_channels]
    state_dict_v2['cv1.conv.weight'] = old_weight[half_channels:]

    # Transfer cv1 batchnorm weights and buffers from C2f to cv0 and cv1 in C2f_v2
    for bn_key in ['weight', 'bias', 'running_mean', 'running_var']:
        old_bn = state_dict[f'cv1.bn.{bn_key}']
        state_dict_v2[f'cv0.bn.{bn_key}'] = old_bn[:half_channels]
        state_dict_v2[f'cv1.bn.{bn_key}'] = old_bn[half_channels:]

    # Transfer remaining weights and buffers
    for key in state_dict:
        if not key.startswith('cv1.'):
            state_dict_v2[key] = state_dict[key]

    # Transfer all non-method attributes
    for attr_name in dir(c2f):
        attr_value = getattr(c2f, attr_name)
        if not callable(attr_value) and '_' not in attr_name:
            setattr(c2f_v2, attr_name, attr_value)

    c2f_v2.load_state_dict(state_dict_v2)

def replace_c2f_with_c2f_v2(module):    #c2f转换函数，模型中所有改进c2f都要放在这(原始c2f_v2上面)
    # for yolov8n.yaml
    for name, child_module in module.named_children():
        if isinstance(child_module, C2f):    #普通c2f转换
            # Replace C2f with C2f_v2 while preserving its parameters
            shortcut = infer_shortcut(child_module.m[0])
            c2f_v2 = C2f_v2(child_module.cv1.conv.in_channels, child_module.cv2.conv.out_channels,
                            n=len(child_module.m), shortcut=shortcut,
                            g=child_module.m[0].cv2.conv.groups,
                            e=child_module.c / child_module.cv2.conv.out_channels)
            transfer_weights_c2f_to_c2f_v2(child_module, c2f_v2)
            setattr(module, name, c2f_v2)
        else:
            replace_c2f_with_c2f_v2(child_module)
    
    # for yolov8-Faster-GFPN-P2-EfficientHead.yaml
    # for name, child_module in module.named_children():
        # if isinstance(child_module, C2f_Faster):  #C2f_Faster转换
        #     # Replace C2f with C2f_v2 while preserving its parameters
        #     shortcut = infer_shortcut(child_module.m[0])
        #     c2f_v2 = C2f_Faster_v2(child_module.cv1.conv.in_channels, child_module.cv2.conv.out_channels, #c2f的改进型必须放在c2f上面
        #                     n=len(child_module.m), shortcut=shortcut,
        #                     g=1,
        #                     e=child_module.c / child_module.cv2.conv.out_channels)
        #     transfer_weights_c2f_to_c2f_v2(child_module, c2f_v2)
        #     setattr(module, name, c2f_v2)
    #     elif isinstance(child_module, C2f_DBB):  #C2f_DBB转换
    #         shortcut = infer_shortcut(child_module.m[0])
    #         c2f_v2 = C2f_DBB_v2(child_module.cv1.conv.in_channels, child_module.cv2.conv.out_channels,
    #                         n=len(child_module.m), shortcut=shortcut,
    #                         g=child_module.m[0].cv2.conv.groups,    #可能是g=1
    #                         e=child_module.c / child_module.cv2.conv.out_channels)
    #         transfer_weights_c2f_to_c2f_v2(child_module, c2f_v2)
    #         setattr(module, name, c2f_v2)
    #     elif isinstance(child_module, C2f_RepConv):  #C2f_RepConv转换
    #         shortcut = infer_shortcut(child_module.m[0])
    #         c2f_v2 = C2f_RepConv_v2(child_module.cv1.conv.in_channels, child_module.cv2.conv.out_channels,
    #                         n=len(child_module.m), shortcut=shortcut,
    #                         g=child_module.m[0].cv2.conv.groups,    #可能是g=1
    #                         e=child_module.c / child_module.cv2.conv.out_channels)
    #         transfer_weights_c2f_to_c2f_v2(child_module, c2f_v2)
    #         setattr(module, name, c2f_v2)
    #     elif isinstance(child_module, C2f):   #普通C2f转换, 如果模型里没有普通c2f则必须注释掉
    #         shortcut = infer_shortcut(child_module.m[0])
    #         c2f_v2 = C2f_v2(child_module.cv1.conv.in_channels, child_module.cv2.conv.out_channels,
    #                         n=len(child_module.m), shortcut=shortcut,
    #                         g=child_module.m[0].cv2.conv.groups,
    #                         e=child_module.c / child_module.cv2.conv.out_channels)
    #         transfer_weights_c2f_to_c2f_v2(child_module, c2f_v2)
    #         setattr(module, name, c2f_v2)
    #     else:
    #         replace_c2f_with_c2f_v2(child_module)
    
    # for yolov8-BIFPN-EfficientRepHead.yaml
    # for name, child_module in module.named_children():
    #     if isinstance(child_module, C2f_EMBC):    #C2f_EMBC转换
    #         # Replace C2f with C2f_v2 while preserving its parameters
    #         shortcut = infer_shortcut(child_module.m[0])
    #         c2f_v2 = C2f_EMBC_v2(child_module.cv1.conv.in_channels, child_module.cv2.conv.out_channels,
    #                         n=len(child_module.m), shortcut=shortcut,
    #                         g=1,
    #                         e=child_module.c / child_module.cv2.conv.out_channels)
    #         transfer_weights_c2f_to_c2f_v2(child_module, c2f_v2)
    #         setattr(module, name, c2f_v2)
    #     elif isinstance(child_module, C2f):   #普通C2f转换, yaml文件中涉及c2f的改进型都要在这里加elif导入
    #         shortcut = infer_shortcut(child_module.m[0])
    #         c2f_v2 = C2f_v2(child_module.cv1.conv.in_channels, child_module.cv2.conv.out_channels,
    #                         n=len(child_module.m), shortcut=shortcut,
    #                         g=child_module.m[0].cv2.conv.groups,
    #                         e=child_module.c / child_module.cv2.conv.out_channels)
    #         transfer_weights_c2f_to_c2f_v2(child_module, c2f_v2)
    #         setattr(module, name, c2f_v2)
    #     else:
    #         replace_c2f_with_c2f_v2(child_module)